export class Inv {
    p_id! : number;
    product!:  string;
    price!:number;
    quantity!:number;
    constructor() {}
}