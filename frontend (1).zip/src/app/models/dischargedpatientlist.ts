export class Dischargedpatientlist {
    d_name!: string;
    p_name!: string;
    d_id!: number;
    confrim!: string;
    d_date!: string; 
    d_time!: string;
    disease!: string;
}
