export class Patient {

        p_id:number;   
        p_name:string;
        p_contact_no:number;
        p_gender:string;
        username:string;
        password:string;
    }

