export class Feedback {
    p_id!: number;
    p_name:string;
    d_name:string;
    p_comments!: string;
    feedback_id:Number;
    constructor() {}
}