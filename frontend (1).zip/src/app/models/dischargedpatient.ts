export class Dischargedpatient {
    d_name!: string;
    p_name!: string;

    confrim!: string;
    d_date!: string; 
    d_time!: string;
    disease!: string;
}
