import { Dischargedpatientlist } from './dischargedpatientlist';

describe('Dischargedpatientlist', () => {
  it('should create an instance', () => {
    expect(new Dischargedpatientlist()).toBeTruthy();
  });
});
