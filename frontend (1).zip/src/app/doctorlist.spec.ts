import { Doctorlist } from './doctorlist';

describe('Doctorlist', () => {
  it('should create an instance', () => {
    expect(new Doctorlist()).toBeTruthy();
  });
});
